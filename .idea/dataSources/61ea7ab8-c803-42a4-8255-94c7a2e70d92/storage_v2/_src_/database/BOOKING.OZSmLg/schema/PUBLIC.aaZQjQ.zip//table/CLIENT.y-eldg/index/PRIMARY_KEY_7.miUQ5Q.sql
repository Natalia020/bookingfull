create unique index PRIMARY_KEY_7
    on CLIENT (ID);

