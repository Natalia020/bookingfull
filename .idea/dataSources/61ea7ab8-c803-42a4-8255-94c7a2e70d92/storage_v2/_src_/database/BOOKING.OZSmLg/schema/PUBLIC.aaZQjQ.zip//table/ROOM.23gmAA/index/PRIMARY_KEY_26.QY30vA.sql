create unique index PRIMARY_KEY_26
    on ROOM (ID);

